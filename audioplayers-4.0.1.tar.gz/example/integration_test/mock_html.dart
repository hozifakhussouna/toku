class DomException {
  String name;
  String? message;

  DomException({required this.name, this.message});
}
